const express = require('express');
const body_parser = require('body-parser');
const url = require('url');

const app = express();


const server = app.listen(3000, function(request, response) {
	console.log('Server is listening on 127.0.0.1:3000');
});

const io = require('socket.io')(server);

app.use(express.static('static'));
app.use(body_parser.json());
app.use(body_parser.urlencoded({extended: true}));

app.set('view engine', 'ejs');

io.on('connection', function(socket) {
	console.log('a user has connected');

	socket.on('posting_form', function(message) {
		console.log(message);

		var random_number = Math.floor((Math.random() * 1000) + 1);
		socket.emit('updated_message', message)
		socket.emit('random_number', random_number);
	});

	socket.on('disconnect', function() {
		console.log('user has disconnected');
	});
});



app.get('/', function(request, response) {

	response.render('index');

});



