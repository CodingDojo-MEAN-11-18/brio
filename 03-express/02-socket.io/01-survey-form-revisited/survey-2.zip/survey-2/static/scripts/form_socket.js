var socket = io();


socket.on('updated_message', function(call) {
	console.log(call);

	var message_container = document.querySelector('#message_container')
	message_container.classList.add('bordered--solid');
	message_container.classList.add('pad');
	message_container.classList.add('bg--lightgreen');

	var message = "You emitted the following information to the server: " + JSON.stringify(call);

	document.querySelector('#updated_message').innerHTML = message;
		
});

socket.on('random_number', function(call) {
	console.log(call);

	var message = "Your lucky number emitted by the server is " + call.toString() + ".";

	document.querySelector('#random_number').innerHTML = message;
});


document.querySelector('#emit_form').onsubmit = function(event) {
	event.preventDefault();

	console.log('hello');

	var name = document.querySelector('.input-name').value;
	var location = document.querySelector('.input-location').value;
	var language = document.querySelector('.input-language').value;
	var comment = document.querySelector('.input-comment').value;

	var full_details = {
		name: name, 
		location: location, 
		language: language, 
		comment: comment, 
	}

	console.log(full_details);
	socket.emit('posting_form', full_details);
};

