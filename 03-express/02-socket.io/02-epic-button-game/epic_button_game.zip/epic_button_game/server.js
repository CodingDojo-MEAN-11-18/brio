const express = require('express');
const app = express();

const port = 6789;
const server = app.listen(port, function() {
	console.log(`Server currently listening on 127.0.0.1:${port}`);
});

const io = require('socket.io')(server);

app.use(express.static('static'));

app.set('view engine', 'ejs');


var current_number = 0;

io.on('connection', function(socket) {
	console.log('a user has connected!');
	socket.emit('current_number', current_number);

	socket.on('update_number', function(message) {
		
		if (message == 'increment') {
			current_number++;
		} else if (message == 'reset') {
			current_number = 0;
		} else {
			current_number = current_number;
		}

		io.emit('current_number', current_number);

	});

	socket.on('disconnect', function() {
		console.log('user has disconnected.');
	});

});

app.get('/', function(request, response) {
	response.render('index');
});