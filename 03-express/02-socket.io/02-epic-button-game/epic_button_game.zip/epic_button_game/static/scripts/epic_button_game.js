var socket = io();

console.log('herllo')

socket.on('current_number', function(call) {
	document.querySelector('#epic_number').innerHTML = call.toString();
});


document.querySelector('#epic_button').onclick = function() {
	socket.emit('update_number', 'increment');
};

document.querySelector('#epic_reset').onclick = function() {
	socket.emit('update_number', 'reset');
};

// document.que