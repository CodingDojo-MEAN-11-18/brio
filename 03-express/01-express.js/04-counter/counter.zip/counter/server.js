
// require express
var express = require("express");
// path module 
var path = require("path");
var session = require('express-session');
// create the express app
var app = express();
var bodyParser = require('body-parser');

// 
app.use(bodyParser.urlencoded({ extended: true }));
// static content
app.use(express.static(path.join(__dirname, "./static")));
// setting up ejs and views folder
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
// root route to render the index.ejs view
var count = 1;

app.get('/', function (req, res) {
    count++
    res.render("index",{ count: count });
})
// post route to add users
app.post('/double', function (req, res) {
    count++
    // Add the user to the DB
    // Then redirect to the root route
    res.redirect('/');
})
app.post('/reset', function (req, res) {
    count = 0
    // Add the user to the DB
    // Then redirect to the root route
    res.redirect('/');
})

// listen on port 8000
app.listen(8000, function () {
    console.log("listening on port 8000");
});
app.use(session({
    secret: 'keyboardkitteh',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}))

