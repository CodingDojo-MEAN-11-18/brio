const express = require('express');
const app = express();



app.set('view engine', 'ejs');
app.use(express.static('static'));


app.get('/cats', function(request, response) {
	response.render('cats', {sample: 'sample data'});
});

app.get('/cars', function(request, response) {
	response.render('cars', {sample: 'sample data'});
});

app.get('/cars/new', function(request, response) {
	response.render('add_car', {sample: 'sample data'});
});


app.listen(8000, function(request, response) {

	console.log('Express app is running on 127.0.0.1:8000');

});

