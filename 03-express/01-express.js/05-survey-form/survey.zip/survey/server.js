const express = require('express');
const app = express();
const body_parser = require('body-parser');
const url = require('url');
//const port = 8000;

app.use(express.static('static'));
app.use(body_parser.json());
app.use(body_parser.urlencoded({extended: true}));

app.set('view engine', 'ejs');


app.get('/', function(request, response) {

	response.render('index');

});


app.post('/result', function(request, response) {

	response.redirect(url.format({
		pathname: '/result',
		query: request.body,
	}));

});


app.get('/result', function(request, response) {

	response.render('result', request.query);

});



app.listen(8000, function(request, response) {
	console.log(`Server is listening on 127.0.0.1:8000`)
});

