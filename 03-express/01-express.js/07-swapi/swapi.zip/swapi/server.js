const express = require('express');
// const https = require('https');
const path = require('path');
const request = require('request');
const body_parser = require('body-parser');

const app = express();
const port = 8000;

app.set('view engine', 'ejs');

app.use(express.static(path.join(__dirname, '/static')))
app.use(body_parser.urlencoded({extended: false}));

app.listen(port, function() {
	console.log(`SWAPI is listening on 127.0.0.1:${port}!`);
});


app.get('/', function(req, res) {
	res.render('index');
});

app.post('/swapi', function(req, res) {

	let post_data = req.body;
	console.log(post_data);

	// https.get(
	// 	'https://swapi.co/api/people?page=' + post_data.page, 
	// 	function(response) {

	// 	let data = '';

	// 	response.on('data', function(chunk_data) {
	// 		data += chunk_data;
	// 	});

	// 	response.on('end', function() {
	// 		response.json( JSON.parse(data) );
	// 	});

	// 	response.on('error', function(error) {
	// 		response.json( JSON.parse({
	// 			'status': 'error', 
	// 			'message': error.message
	// 		}) );
	// 	});

	// });
	
	request('https://swapi.co/api/people?page=' + post_data.page, {json:true}, function(error, resp, body) {
		if (error) {
			console.log(error);
		}

		res.json(body);

	});

});