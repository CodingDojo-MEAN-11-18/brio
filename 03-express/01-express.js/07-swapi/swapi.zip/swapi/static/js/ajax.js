// =============================================================

//				FETCH ALL FUNCTIONALITY 

// =============================================================

document.addEventListener('DOMContentLoaded', function() {
	console.log('html loaded.');

	// fetch_data(1);
	initiate_fetcher(1);
	// initiate_fetcher([1, 10])

	disable_clicking('.fetch-all');
	document.querySelector('.fetch-all')
	.addEventListener('click', function() {
		initiate_fetcher([1, this.value]);
	});

	document.querySelector('.next')
	.addEventListener('click', function() {
		// console.log(this.value);
		initiate_fetcher(parseInt(this.value));
	});

	document.querySelector('.previous')
	.addEventListener('click', function() {
		initiate_fetcher(parseInt(this.value));
	});

});



function initiate_fetcher(page_number) {
	// console.log(typeof page_number);

	let container = document.getElementById('information');
	container.innerHTML = '';

	if (typeof page_number == 'object') {
		// console.log('this is an array');

		// for (let i=1; i<=page_number[1]; i++) {
		// 	fetch_data(i, true);
		// }

		fetch_data(page_number[0], true, page_number[1]);

	} else if (typeof page_number == 'number') {
		// console.log('this is a number');

		fetch_data(page_number, false);

	} else {
		console.error('Invalid fetcher data');

	}


}



function fetch_data(page_number, fetched_all=false, till_page=0) {

	let xhr = new XMLHttpRequest();

	xhr.onload = function() {

		if (xhr.status >= 200 && xhr.status < 300) {

			let response = JSON.parse(xhr.response);

			// console.log(response);
			// console.log(typeof response);

			display_data(response);
			check_data(response, fetched_all);

			if (page_number < till_page) {
				page_number += 1;
				fetch_data(page_number, true, till_page);
			}

		} else {

			console.error('Error', xhr);

		}

	};

	xhr.open('POST', '/swapi');
	xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

	xhr.send(encodeURI('page=' + page_number));

}



function display_data(data) {

	let container = document.getElementById('information');

	if (!(data)) {
		// console.log('Data not found.');
		return false
	}

	let name, br;
	(data.results).forEach(function(entry, index, array) {
		name = document.createTextNode(entry.name);
		br = document.createElement('br');

		container.appendChild(name);
		container.appendChild(br);
	});

}



function disable_clicking(query_selector) {
	document.querySelector(query_selector)
		.setAttribute('disabled', 'disabled');
}



function enable_clicking(query_selector) {
	document.querySelector(query_selector)
		.removeAttribute('disabled');
}



function enable_or_disable(data, query_selector) {
	if (data == null) {
		disable_clicking(query_selector);
	} else {
		enable_clicking(query_selector);
	}
}



function set_attribute(query_selector, attribute, value) {
	document.querySelector(query_selector)
		.setAttribute(attribute, value);
}


function get_page_number(string) {

	// console.log(string);
	if (string == null) {
		return string
	}

	let matched = string.match(/page=\d/);

	if (matched != null) {
		return parseInt(matched[0].replace('page=', ''))
	}

	return matched

}



function calculate_pages(count) {
	return Math.ceil(count / 10)
}



function check_data(data, fetched_all=false) {

	if (!(data)) {
		// console.log('Data not found.');
		return false
	}

	document.querySelector('.swapi-numbers').innerHTML = data.count;

	enable_or_disable(data.previous, '.previous');
	enable_or_disable(data.count, '.fetch-all');
	enable_or_disable(data.next, '.next');

	set_attribute('.previous', 'value', get_page_number(data.previous));
	set_attribute('.fetch-all', 'value', calculate_pages(data.count));
	set_attribute('.next', 'value', get_page_number(data.next));

	if (fetched_all) {
		set_attribute('.previous', 'value', 1);
		set_attribute('.fetch-all', 'value', 1);
		set_attribute('.next', 'value', 2);

		disable_clicking('.next');
		disable_clicking('.fetch-all');
	}

}
