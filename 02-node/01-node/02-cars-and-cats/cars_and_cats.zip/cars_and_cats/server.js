var http = require('http');
var fs = require('fs');


http.createServer(function(request, response) {

	var path = request.url;

	// VIEWS
	if (
		path.toLowerCase() === '/cars/'
		|| path.toLowerCase() === '/cars'
		) {

		fs.readFile('./views/cars.html', function(error, data) {
			response.writeHead(200, {'Content-Type': 'text/html'});
			response.write(data);
			response.end();
		});

	} else if (
		path.toLowerCase() === '/cats/'
		|| path.toLowerCase() === '/cats'
		) {

		fs.readFile('./views/cats.html', function(error, data) {
			response.writeHead(200, {'Content-Type': 'text/html'});
			response.write(data);
			response.end();
		});

	} else if (
		path.toLowerCase() === '/cars/new/'
		|| path.toLowerCase() === '/cars/new'
		) {

		fs.readFile('./views/add_car.html', function(error, data) {
			response.writeHead(200, {'Content-Type': 'text/html'});
			response.write(data);
			response.end();
		});

	// STYLESHEETS
	} else if (path.toLowerCase() === '/stylesheets/style-cars.css') {

		fs.readFile('./stylesheets/style-cars.css', 'utf8', function(error, contents) {
			response.writeHead(200, {'Content-Type': 'text/css'});
			response.write(contents);
			response.end();
		});

	} else if (path.toLowerCase() === '/stylesheets/style-cats.css') {

		fs.readFile('./stylesheets/style-cats.css', 'utf8', function(error, contents) {
			response.writeHead(200, {'Content-Type': 'text/css'});
			response.write(contents);
			response.end();
		});

	// IMAGES
	} else if (path.toLowerCase() === '/images/car_1.jpg') {

		fs.readFile('./images/car_1.jpg', function(error, contents) {
			response.writeHead(200, {'Content-Type': 'image/jpeg'});
			response.write(contents);
			response.end();
		});

	} else if (path.toLowerCase() === '/images/car_2.jpg') {

		fs.readFile('./images/car_2.jpg', function(error, contents) {
			response.writeHead(200, {'Content-Type': 'image/jpeg'});
			response.write(contents);
			response.end();
		});

	} else if (path.toLowerCase() === '/images/car_3.jpg') {

		fs.readFile('./images/car_3.jpg', function(error, contents) {
			response.writeHead(200, {'Content-Type': 'image/jpeg'});
			response.write(contents);
			response.end();
		});

	} else if (path.toLowerCase() === '/images/cat_1.jpg') {

		fs.readFile('./images/cat_1.jpg', function(error, contents) {
			response.writeHead(200, {'Content-Type': 'image/jpeg'});
			response.write(contents);
			response.end();
		});

	} else if (path.toLowerCase() === '/images/cat_2.jpg') {

		fs.readFile('./images/cat_2.jpg', function(error, contents) {
			response.writeHead(200, {'Content-Type': 'image/jpeg'});
			response.write(contents);
			response.end();
		});

	} else if (path.toLowerCase() === '/images/cat_3.jpg') {

		fs.readFile('./images/cat_3.jpg', function(error, contents) {
			response.writeHead(200, {'Content-Type': 'image/jpeg'});
			response.write(contents);
			response.end();
		});

	}

}).listen(7077);

console.log('Server is running on 127.0.0.1:7077');
