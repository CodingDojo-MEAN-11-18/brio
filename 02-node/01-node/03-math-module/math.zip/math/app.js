var mathlib = require('./mathlib');

console.log('============== Addition ================');
console.log( mathlib().add(1, 1) );
console.log( mathlib().add(2, 2) );
console.log( mathlib().add(3, 3) );
console.log( mathlib().add(4, 4) );

console.log('============== Multiplication ================');
console.log( mathlib().multiply(1, 10) );
console.log( mathlib().multiply(2, 10) );
console.log( mathlib().multiply(3, 10) );
console.log( mathlib().multiply(4, 10) );

console.log('============== Square ================');
console.log( mathlib().square(2) );
console.log( mathlib().square(10) );
console.log( mathlib().square(50) );
console.log( mathlib().square(100) );

console.log('============== Random ================');
console.log( mathlib().random(1, 100) );
console.log( mathlib().random(1, 1000) );
console.log( mathlib().random(1, 10000) );
console.log( mathlib().random(1, 100000) );
