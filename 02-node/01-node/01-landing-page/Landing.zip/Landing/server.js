var http = require('http');
var fs = require('fs');


http.createServer(function(request, response) {

	var path = request.url;

	if (path === '/' || path === '') {

		fs.readFile('index.html', function(error, data) {
			response.writeHead(200, {'Content-Type': 'text/html'});
			response.write(data);
			response.end();
		});

	} else if (
		path.toLowerCase() === '/ninjas/' 
		|| path.toLowerCase() === '/ninjas'
		) {

		fs.readFile('ninjas.html', function(error, data) {
			response.writeHead(200, {'Content-Type': 'text/html'});
			response.write(data);
			response.end();
		});

	} else if (
		path.toLowerCase() === '/dojos/new/'
		|| path.toLowerCase() === '/dojos/new'
		) {

		fs.readFile('dojos.html', function(error, data) {
			response.writeHead(200, {'Content-Type': 'text/html'});
			response.write(data);
			response.end();
		});

	} else {

		fs.readFile('404.html', function(error, data) {
			response.writeHead(200, {'Content-Type': 'text/html'});
			response.write(data);
			response.end();
		});

	}

}).listen(6789);

console.log('Server is running on 127.0.0.1:6789');