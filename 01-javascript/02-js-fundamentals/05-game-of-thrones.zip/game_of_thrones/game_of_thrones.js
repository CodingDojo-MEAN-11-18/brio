document.addEventListener('DOMContentLoaded', function() {
	console.log('html loaded.');

	let game_of_thrones = new GameOfThrones();

	let fetchers = document.getElementsByClassName('fetcher');

	for (let i=0; i<fetchers.length; i++) {
		fetchers[i].addEventListener('click', function(event) {
			event.preventDefault();

			console.log('hello');
			game_of_thrones.fetch_information(
				fetchers[i].getAttribute('value'));

		});
	}

});



function GameOfThrones() {}



GameOfThrones.prototype.fetch_information = function(url) {

	let xhr = new XMLHttpRequest();

	xhr.onload = function(data) {
		if (xhr.status >= 200 && xhr.status < 300) {
			console.log(xhr.response);

			GameOfThrones.prototype.result = xhr.response;
			GameOfThrones.prototype.display_information();

		} else {
			console.error('Ajax request failed.');
		}
	}
	console.log(url);
	xhr.open('GET', url);
	xhr.send();

}


GameOfThrones.prototype.display_information = function() {

	let house_info = GameOfThrones.prototype.result;

	if (typeof house_info == 'string') {
		house_info = JSON.parse(house_info);
	}

	let house_details = document.getElementById('house_details');

	let legend = document.createElement('legend');
	let legend_text = document.createTextNode('House Details');

	let h2 = document.createElement('h2');
	let h2_text = document.createTextNode('Name: ' + house_info.name);
	h2.id = 'house_name';
	let h4 = document.createElement('h4');
	let h4_text = document.createTextNode('Words: ' + house_info.words);
	h4.id = 'house_words';
	let p = document.createElement('p');
	let p_text = document.createTextNode(
		'Titles: ' + (house_info.titles).join(', ') );
	p.id = 'house_information';

	house_details.innerHTML = '';

	legend.appendChild(legend_text);
	h2.appendChild(h2_text);
	h4.appendChild(h4_text);
	p.appendChild(p_text);

	house_details.appendChild(legend);
	house_details.appendChild(h2);
	house_details.appendChild(h4);
	house_details.appendChild(p);

}