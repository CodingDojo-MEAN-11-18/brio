document.addEventListener("DOMContentLoaded", function(event) {
	// console.log('html loaded.');

	let game = new TriviaGame(0);
	game.generate_game();

});

function TriviaGame(score) {
	// console.log(score);
	TriviaGame.prototype.score = parseInt(score);
}


// function generate_game() {
TriviaGame.prototype.generate_game = function() {

	let xhr = new XMLHttpRequest();
	// let d = document;

	xhr.onload = function() {

		if (xhr.status >= 200 && xhr.status < 300) {
			let result = JSON.parse( xhr.response );

			TriviaGame.prototype.all_trivia = result;
			// prepare_gameboard(result);
			TriviaGame.prototype.prepare_gameboard();

			// d.querySelector('#send_here').innerHTML = result;
		} else {
			console.error('Request failed.');

		}
		// return {response_code: 500}
	};

	xhr.open('GET', 'https://opentdb.com/api.php?amount=9&type=multiple');
	xhr.send();

}


// function create_div(class_name) {
TriviaGame.prototype.create_div = function(class_name) {

	// let d = document;
	
	let div = document.createElement('div');
	div.classList.add(class_name);

	return div
}


// function create_row(how_many_rows, selector) {
TriviaGame.prototype.create_row = function(how_many_rows, selector) {

	// let d = document;
	
	let then = document.querySelector(selector);
	let this_row;

	for (let i=1; i<how_many_rows+1; i++) {
		this_row = TriviaGame.prototype.create_div('row--' + i.toString());
		this_row.classList.add('flex');
		this_row.classList.add('height--third');
		this_row.classList.add('width--100')

		then.appendChild(this_row);
	}


}


// function get_score(difficulty) {
TriviaGame.prototype.get_score = function(difficulty) {

	let score;

	if (difficulty === 'easy') {
		score = 10;
	} else if (difficulty === 'medium') {
		score = 25;
	} else if (difficulty === 'hard') {
		score = 50;
	} else {
		score = 1;
	}

	return score
}


// function disable_clicking(class_name) {
TriviaGame.prototype.click_toggler = function(class_name, switch_it_on=true) {
	let class_buttons = document.getElementsByClassName(class_name);

	// console.log(class_buttons);

	for (let i=0; i<class_buttons.length; i++) {
		if (switch_it_on) {
			// console.log('added');
			class_buttons[i].setAttribute('disabled', 'disabled');
		} else {
			// console.log('removed');
			class_buttons[i].removeAttribute('disabled');
		}
	}
}


// function create_question_box(trivia, row_number) {
TriviaGame.prototype.create_question_box = function(trivia, row_number) {

	// let d = document;

	let score = TriviaGame.prototype.get_score(trivia.difficulty);

	let box = TriviaGame.prototype.create_div('question-box');
	box.classList.add('even');
	box.classList.add('bordered');
	box.classList.add('width--third');
	box.classList.add('flex');
	box.classList.add('flex--column');
	box.id = "box_" + trivia.question_id;

	// console.log('creating button');

	let category = document.createTextNode(trivia.category);
	let paragraph = document.createElement('p');

	let button = document.createElement('button');
	button.classList.add('question-reveal');
	button.id = trivia.question_id;
	
	button.addEventListener('click', function(event) {
		// console.log(TriviaGame.prototype.id);
		// reveal_question(TriviaGame.prototype.id, all_trivia);
		// console.log('hello')
		TriviaGame.prototype.reveal_question(button.id);
		TriviaGame.prototype.click_toggler('question-reveal', true)
	});

	let question_score = document.createTextNode(score);

	paragraph.appendChild(category);
	paragraph.classList.add('text-center');
	button.appendChild(question_score);

	box.appendChild(paragraph);
	box.appendChild(button);

	// console.log(row_number)
	document.querySelector('#game_question .row--' + row_number).appendChild(box);

}


// function makeid() {
TriviaGame.prototype.makeid = function() {

	let text = "";
	let possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

	for (let i=0; i<10; i++) {
		text += possible.charAt(Math.floor(Math.random() * possible.length));
	}

	return text;

}


// function prepare_gameboard(data) {
// TriviaGame.prototype.prepare_gameboard = function(data) {
TriviaGame.prototype.prepare_gameboard = function() {

	document.querySelector('#game_question').innerHTML = '';
	// let all_trivia = data.results;
	let all_trivia = TriviaGame.prototype.all_trivia.results;
	let number_of_rows = 3;

	TriviaGame.prototype.create_row(number_of_rows, '#game_question');

	let row_number = 1;
	let question_id;
	all_trivia.forEach(function(trivia, index, array) {
		// console.log(trivia);
		// question_id = makeid();
		question_id = TriviaGame.prototype.makeid();
		trivia['question_id'] = question_id;

		TriviaGame.prototype.create_question_box(trivia, row_number);

		if ((index+1) % number_of_rows === 0) {
			// console.log(index+1)
			// console.log(number_of_rows)
			// console.log((index+1) % number_of_rows)
			row_number++;
		}

	});

}


// ========================================

// 			QUESTIONS PREPARATION

// ========================================


// function shuffle(array) {
TriviaGame.prototype.shuffle = function(array) {

	let index = array.length;
	let temporary;
	let random_number;

	while (index != 0) {
		random_number = Math.floor(
			Math.random() * array.length
			);
		index--;
		// console.log(random_number)
		// console.log(index)

		temporary = array[index];
		array[index] = array[random_number];
		array[random_number] = temporary;

		// console.log(array);
	}

	// for (let i=array.length-1; i>=0; i--) {
	// 	random_number = Math.floor(
	// 		Math.random() * i
	// 		);
	// 	temporary = array[i];
	// 	array[i] = array[random_number];
	// 	array[random_number] = temporary;
	// }

	return array

}


// function search_trivia(question_id, all_trivia) {
// TriviaGame.prototype.search_trivia = function(question_id, all_trivia) {
TriviaGame.prototype.search_trivia = function(question_id) {

	// console.log(all_trivia);
	let all_trivia = TriviaGame.prototype.all_trivia.results;
	let return_this;

	all_trivia.forEach(function(trivia, index, array) {
		if (trivia.question_id == question_id) {
			// console.log(question_id);
			// console.log(trivia);
			// return trivia
			return_this = trivia;
		}
	});

	return return_this

}


TriviaGame.prototype.update_score = function() {
	let score = this.score;
	// console.log(score);

	document.querySelector('#game_score').innerHTML = score;
}


TriviaGame.prototype.add_score = function(difficulty) {
	score = TriviaGame.prototype.get_score(difficulty);
	// console.log(score);

	// TriviaGame.prototype.score += score;
	TriviaGame.prototype.score = (
		parseInt(TriviaGame.prototype.score) + parseInt(score)
		);
	TriviaGame.prototype.update_score();
}


TriviaGame.prototype.check_answer = function(trivia, answer, is_correct=false) {
	if (is_correct) {
		// console.log(trivia);
		TriviaGame.prototype.add_score(trivia.difficulty);
	}

	let choices = document.querySelectorAll(
		'#box_' + trivia.question_id + ' .choices'
		);

	// console.log( choices );

	for (let i=0; i<choices.length; i++) {

		if (choices[i].value == trivia.correct_answer) {
			choices[i].classList.add('correct');
		} else if (choices[i].value == answer) {
			choices[i].classList.add('wrong');
		}

	}
}


// function reveal_answer(question_id, answer, all_trivia) {
// TriviaGame.prototype.reveal_answer = function(question_id, answer, all_trivia) {
TriviaGame.prototype.reveal_answer = function(question_id, answer) {

	// console.log(question_id);
	// console.log(answer);
	let all_trivia = TriviaGame.prototype.all_trivia.results;

	// FOR CHECKING
	all_trivia.forEach(function(trivia, index, array) {
		if (trivia.question_id == question_id) {
			// console.log(answer);
			if (trivia.correct_answer == answer) {
				// console.log("correct answer");
				// TriviaGame.prototype.correct_answer(trivia, true);
				TriviaGame.prototype.check_answer(trivia, answer, true);
			} else {
				// console.log("wrong answer");
				// TriviaGame.prototype.wrong_answer(trivia, answer);
				// TriviaGame.prototype.correct_answer(trivia, false);
				TriviaGame.prototype.check_answer(trivia, answer, false);
			}
		}
	});

	TriviaGame.prototype.check_number_of_questions();

}


// function reveal_question(question_id, all_trivia) {
// TriviaGame.prototype.reveal_question = function(question_id, all_trivia) {
TriviaGame.prototype.reveal_question = function(question_id) {

	// console.log(question_id);
	// let d = document;
	let all_trivia = TriviaGame.prototype.all_trivia.results;
	let box = document.querySelector('#box_' + question_id);
	// let trivia = search_trivia(question_id, all_trivia);
	let trivia = TriviaGame.prototype.search_trivia(question_id);
	// console.log(trivia);

	// QUESTION PORTION
	let question_div = TriviaGame.prototype.create_div('question');
	let question = document.createTextNode(
		TriviaGame.prototype.decode_special_characters(trivia.question)
		);
	let paragraph = document.createElement('p');
	paragraph.classList.add('text-center');

	box.innerHTML = "";
	paragraph.appendChild(question);
	question_div.appendChild(paragraph);
	box.appendChild(question_div);

	// CHOICES PORTION
	let choices_div = TriviaGame.prototype.create_div('choices');
	choices_div.classList.add('flex');
	choices_div.classList.add('flex--row');

	let answers = [
		trivia.correct_answer,
		trivia.incorrect_answers[0],
		trivia.incorrect_answers[1],
		trivia.incorrect_answers[2],
	];
	let shuffled_choices = TriviaGame.prototype.shuffle(answers);
	
	// console.log(answers);
	// console.log(shuffled_choices);

	let button, text;
	shuffled_choices.forEach(function(choice, index, array) {
		button = document.createElement('button');
		button.value = choice;
		button.classList.add('answer--' + question_id);
		button.classList.add('even');
		button.classList.add('choices');

		button.addEventListener('click', function(event) {
			TriviaGame.prototype.reveal_answer(question_id, this.value, array);
			TriviaGame.prototype.click_toggler('question-reveal', false);
			TriviaGame.prototype.click_toggler('choices', true);
		});

		text = document.createTextNode(
			TriviaGame.prototype.decode_special_characters(choice)
			);

		button.appendChild(text);
		choices_div.appendChild(button);
	});

	box.appendChild(choices_div);

}


TriviaGame.prototype.check_number_of_questions = function() {
	let questions_left = document.getElementsByClassName('question-reveal');

	if (questions_left.length === 0) {
		TriviaGame.prototype.continue_game_or_not();
	}
}


TriviaGame.prototype.continue_game_or_not = function() {
	let header = document.querySelector('#game_header');
	let first_child = document.querySelector('#game_header h1');

	let button = document.createElement('button');
	button.id = 'continue';
	let text = document.createTextNode('Continue with new questions');

	button.appendChild(text);

	header.insertBefore(button, first_child);

	button.addEventListener('click', function(event) {
		TriviaGame.prototype.generate_game();

		button.parentNode.removeChild(button);
	});
}


TriviaGame.prototype.decode_special_characters = function(string) {
	let text = document.createElement('textarea');
	text.innerHTML = string;

	return text.value
}