const express = require('express');
const body_parser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
const port = 8000;
const note_routes = require(__dirname + '/server/config/routes')
const db = require(__dirname + '/server/config/mongoose');



app.use(body_parser.urlencoded({extended: true}));
app.use(body_parser.json());
app.use(express.static(__dirname + '/public/dist/public'));
app.use('/notes', note_routes);

app.listen(port, function() {
	console.log(`Server is listening on 127.0.0.1:${port}!`);
});


