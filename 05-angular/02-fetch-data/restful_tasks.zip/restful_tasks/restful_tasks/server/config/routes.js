const router = require('express').Router();

const tasks = require(__dirname + '/../controllers/tasks');


router.get('/all', tasks.all);
router.post('/create', tasks.create);
router.get('/:id', tasks.show);
router.put('/:id/edit', tasks.edit);
router.delete('/:id/destroy', tasks.destroy);


module.exports = router;