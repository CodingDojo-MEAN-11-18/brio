const express = require('express');
const body_parser = require('body-parser');

const port = 8000;
const app = express();
const task_router = require(__dirname + '/server/config/routes');
const db = require(__dirname + '/server/config/mongoose.js');



app.use(body_parser.json());
app.use(body_parser.urlencoded({extended: true}));
app.use(express.static(__dirname + '/public/dist/public'));
app.use('/tasks', task_router);

app.listen(port, function() {
	console.log(`Restful Task API is listening on 127.0.0.1:${port}!`);
});



