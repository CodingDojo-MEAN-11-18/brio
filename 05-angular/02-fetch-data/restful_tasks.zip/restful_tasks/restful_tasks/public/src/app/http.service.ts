import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private _http: HttpClient) {
  	console.log('constructor initiated');	
  	this.getTasks();
  }

  getTasks() {
  	let tempObservable = this._http.get('/tasks/all');

  	console.log('getting tasks..');
  	tempObservable.subscribe(data => {
  		console.log('Got all tasks!', data);

  		if (data['tasks'].length > 0) {
  			data['tasks'].forEach((task, index, array) => {
  				this.getSpecificTask(task._id);
  			})
  		}
  	});
  }

  getSpecificTask(task_id) {
  	let tempObservable = this._http.get(`/tasks/${task_id}`);

  	console.log('getting specific task..');
  	tempObservable.subscribe(data => console.log('Got a specific task!', data));
  }
}
