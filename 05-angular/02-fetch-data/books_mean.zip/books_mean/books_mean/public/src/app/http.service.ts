import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  created_author: any;
  book_id: any;

  constructor(private _http: HttpClient) {
  	console.log('initiate books api');
  	this.get_all_authors();
  	this.create_author();
  }

  get_all_authors() {
  	let observable = this._http.get('/authors/all');

  	observable.subscribe(data => {
  		console.log('Got all the authors! ', data);
  	});
  }

  create_author() {
  	let create_params = {
  		first_name: 'James',
  		last_name: 'Harden',
  		country: 'Canada',
  		birthdate: '1988-06-30',
  		title: 'The Life of a Programmer',
  		pub_date: '2018-12-02',
  	};
  	let observable = this._http.post('/authors/create', create_params);

  	observable.subscribe(data => {
  		console.log('Created an author and a book', data);

  		this.created_author = data['result'];

  		this.show_author();
  	});
  }

  show_author() {
  	console.log(this.created_author);
  	let observable = this._http.get(`/authors/${this.created_author['_id']}`);

  	observable.subscribe(data => {
  		console.log('Got the author!', data['result']);

  		this.update_author();
  	})
  }

  update_author() {
  	let update_params = {
  		first_name: 'LeBron',
  		last_name: 'James',
  	};
  	let observable = this._http.put(
  		`/authors/${this.created_author['_id']}/update`, update_params);

  	observable.subscribe(data => {
  		console.log('Updated the author!', data['result']);

  		this.create_book();
  	});
  }

  delete_author() {
  	let observable = this._http.delete(
  		`/authors/${this.created_author['_id']}/destroy`);

  	observable.subscribe(data => {
  		console.log('Deleted the author!', data);
  	})
  }

  create_book() {
  	let create_params = {
  		title: 'The Life of Another Programmer',
  		pub_date: '1900-12-20',
  	};
  	let observable = this._http.post(
  		`/authors/${this.created_author['_id']}/create`, create_params);

  	observable.subscribe(data => {
  		console.log('Created a book for an existing author!', data['result']);

  		console.log(data['result'])
  		this.book_id = data['result']['books'][0]['_id'];
  		console.log('Id of the first book of the author', this.book_id);

  		this.delete_book();
  	});
  }

  delete_book() {
  	let observable = this._http.delete(
  		`/authors/${this.created_author['_id']}/destroy/${this.book_id}`);

  	observable.subscribe(data => {
  		console.log('Response on deleting a book', data);

  		this.delete_author();
  	})
  }
}
