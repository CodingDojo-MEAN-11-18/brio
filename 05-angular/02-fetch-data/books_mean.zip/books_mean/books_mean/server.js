const body_parser = require('body-parser');
const express = require('express');

const app = express();
const port = 8000;
const db = require(__dirname + '/server/config/mongoose');
const author_book_router = require(__dirname + '/server/config/author_book_routes');


app.use(body_parser.urlencoded({extended: true}));
app.use(body_parser.json());
app.use(express.static(__dirname + '/public/dist/public'));
app.use('/authors', author_book_router);

app.listen(port, function() {
	console.log(`Server is listening on 127.0.0.1:${port}`);
});