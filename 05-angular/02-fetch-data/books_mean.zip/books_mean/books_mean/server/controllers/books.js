const ObjectId = require('mongoose').Types.ObjectId;

const AuthorBook = require(__dirname + '/../models/author-book');



let book_functions = {

	create: function(req, res) {
		// res.json({status: true});

		let create_params = {
			title: req.body.title,
			pub_date: new Date(req.body.pub_date),
		}

		AuthorBook.findOne({_id: ObjectId(req.params.author_id)})
		.exec(function(error, author) {
			author.books.push(create_params);

			author.save(function(error) {
				let status = true;
				let messages = {};

				if (error) {
					status = false;

					Object.keys(error.errors).forEach(function(err, index) {
						messages[err] = error.errors[err].message;
					});

					res.json({status: status, messages: messages});
				}

				res.json({status: status, messages: messages, result: author});
			})

		});

	},

	destroy: function(req, res) {
		// res.json({status: true});

		AuthorBook.findOne({_id: ObjectId(req.params.author_id)})
		.exec(function(error, author) {
			author.books.id(ObjectId(req.params.book_id)).remove();

			author.save(function(error) {
				let status = true;
				let messages = {};

				if (error) {
					status = false;

					Object.keys(error.errors).forEach(function(err, index) {
						messages[err] = error.errors[err].message;
					});

					res.json({status: status, messages: messages});
				}

				res.json({status: status, messages: messages, result: author});
			})

		});

	},

};



module.exports = book_functions;