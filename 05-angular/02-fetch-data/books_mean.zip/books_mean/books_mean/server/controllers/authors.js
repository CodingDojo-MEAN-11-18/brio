const ObjectId = require('mongoose').Types.ObjectId;

const AuthorBook = require(__dirname + '/../models/author-book');



let author_functions = {

	all: function(req, res) {
		// res.json({status: true});

		AuthorBook.find({}).exec(function(error, authors) {
			let status = false;

			if (!error) {
				status = true;
			}

			res.json({status: status, result: authors});
		});

	},

	create: function(req, res) {
		// res.json({status: true});

		let create_params = {
			first_name: req.body.first_name,
			last_name: req.body.last_name,
			country: req.body.country,
			birthdate: new Date(req.body.birthdate),
			books: {
				title: req.body.title,
				pub_date: new Date(req.body.pub_date),
			}
		}

		let new_author_book = new AuthorBook(create_params);

		new_author_book.save(function(error) {
			let status = true;
			let messages = {};

			if (error) {
				status = false;

				Object.keys(error.errors).forEach(function(err, index) {
					messages[err] = error.errors[err].message;
				});

				res.json({status: status, messages: messages});
			}

			res.json({
				status: status, 
				messages: messages, 
				result: new_author_book
			});

		});

	},

	show: function(req, res) {
		// res.json({status: true});

		AuthorBook.find({_id: ObjectId(req.params.id)}).exec(function(error, author) {
			let status = true;
			let messages = {};

			if (error) {
				status = false;

				Object.keys(error.errors).forEach(function(err, index) {
					messages[err] = error.errors[err].message;
				});
				
				res.json({status: status, messages: messages});
			}

			res.json({status: status, messages: messages, result: author});
		});
		
	},

	edit: function(req, res) {
		// res.json({status: true});

		AuthorBook.findOneAndUpdate(
			{_id: ObjectId(req.params.id)},
			{$set: req.body},
			{runValidators: true, new: true},
			function(error, author) {
				let status = true;
				let messages = {};

				if (error) {
					status = false;

					Object.keys(error.errors).forEach(function(err, index) {
						messages[err] = error.errors[err].message;
					});

					res.json({status: status, messages: messages});
				}

				res.json({status: status, messages: messages, result: author});

			}
		);
	},

	destroy: function(req, res) {
		// res.json({status: true});

		AuthorBook.findOneAndDelete(
			{_id: ObjectId(req.params.id)},
			function(error, author) {
				let status = true;
				let messages = {};

				if (error) {
					status = false;

					Object.keys(error.errors).forEach(function(err, index) {
						messages[err] = error.errors[err].message;
					});
				}

				res.json({status: status, messages: messages})

			}
		);
	},

};



module.exports = author_functions;