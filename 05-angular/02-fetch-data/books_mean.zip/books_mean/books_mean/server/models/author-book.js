const mongoose = require('mongoose');

const Schema = mongoose.Schema;


let AuthorBookSchema = new Schema({
	first_name: {
		type: String,
		required: true,
		minlength: 2,
	},
	last_name: {
		type: String,
		required: true,
		minlength: 2,
	},
	country: {
		type: String,
		required: true,
		minlength: 3,
	},
	birthdate: {
		type: Date,
		validate: (d) => {return new Date(d) < Date.now()},
	},
	books: [
		new Schema({
			title: {
				type: String,
				required: true,
				minlength: 2,
			},
			pub_date: {
				type: Date,
				validate: (d) => {return new Date(d) < Date.now()},
			},
		})
	]
});

let AuthorBook = mongoose.model('AuthorBook', AuthorBookSchema);



module.exports = AuthorBook;