const mongoose = require('mongoose');

const mongo_url = 'mongodb://localhost/books';
mongoose.connect(mongo_url, {useNewUrlParser: true});
mongoose.Promise = global.Promise;

const db = mongoose.connection;



db.once('open', function() {
	console.log(`Database connected.`);
});

db.on('error', function() {
	console.log('Database error: closed unexpectedly.');
});



module.exports = db;