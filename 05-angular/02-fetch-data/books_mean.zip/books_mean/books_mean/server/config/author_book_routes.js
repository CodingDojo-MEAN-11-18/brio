const router = require('express').Router();

const authors = require(__dirname + '/../controllers/authors');
const books = require(__dirname + '/../controllers/books');


// authors
router.get('/all', authors.all);
router.post('/create', authors.create);
router.get('/:id', authors.show);
router.put('/:id/update', authors.edit);
router.delete('/:id/destroy', authors.destroy);
// books
router.post('/:author_id/create', books.create);
router.delete('/:author_id/destroy/:book_id', books.destroy);



module.exports = router;