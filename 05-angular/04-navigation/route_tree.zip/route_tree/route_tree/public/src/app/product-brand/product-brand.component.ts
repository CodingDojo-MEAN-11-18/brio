import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-brand',
  templateUrl: './product-brand.component.html',
  styleUrls: ['./product-brand.component.css', '../app.component.css']
})
export class ProductBrandComponent implements OnInit {
  route_parameter: any;

  constructor(private _route: ActivatedRoute) { }

  ngOnInit() {
  	this._route.params.subscribe(params => {
  		console.log('Got the parameter', params);

  		this.route_parameter = params;
  	})
  }

}
