import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-review-details',
  templateUrl: './review-details.component.html',
  styleUrls: ['./review-details.component.css', '../app.component.css']
})
export class ReviewDetailsComponent implements OnInit {
  route_parameter: any;

  constructor(private _route: ActivatedRoute) { }

  ngOnInit() {
  	this._route.params.subscribe(params => {
  		console.log('Got the review detail id!', params);

  		this.route_parameter = params;
  	});
  }

}
