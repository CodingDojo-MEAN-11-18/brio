import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ProductsComponent } from './products/products.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ProductBrandComponent } from './product-brand/product-brand.component';
import { ProductCategoryComponent } from './product-category/product-category.component';

import { ReviewsComponent } from './reviews/reviews.component';
import { ReviewAllComponent } from './review-all/review-all.component';
import { ReviewAuthorComponent } from './review-author/review-author.component';
import { ReviewDetailsComponent } from './review-details/review-details.component';

const routes: Routes = [
	{path: 'products', component: ProductsComponent, children: [
		{path: 'details/:id', component: ProductDetailsComponent},
		{path: 'brand/:brand', component: ProductBrandComponent},
		{path: 'category/:cat', component: ProductCategoryComponent},
	]},
	{path: 'reviews', component: ReviewsComponent, children: [
		{path: 'details/:id', component: ReviewDetailsComponent},
		{path: 'all/:id', component: ReviewAllComponent},
		{path: 'author/:id', component: ReviewAuthorComponent},
	]},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
