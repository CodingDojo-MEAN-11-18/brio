import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-category',
  templateUrl: './product-category.component.html',
  styleUrls: ['./product-category.component.css', '../app.component.css']
})
export class ProductCategoryComponent implements OnInit {
  route_parameter: any;

  constructor(private _route: ActivatedRoute) { }

  ngOnInit() {
  	this._route.params.subscribe(params => {
  		console.log('Got the category! ', params);

  		this.route_parameter = params;
  	});
  }

}
