import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-review-author',
  templateUrl: './review-author.component.html',
  styleUrls: ['./review-author.component.css', '../app.component.css']
})
export class ReviewAuthorComponent implements OnInit {
  route_parameter: any;

  constructor(private _route: ActivatedRoute) { }

  ngOnInit() {
  	this._route.params.subscribe(params => {
  		console.log('Got the author id! ', params);

  		this.route_parameter = params;
  	});
  }

}
