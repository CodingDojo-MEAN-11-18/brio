import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css', '../app.component.css']
})
export class ProductDetailsComponent implements OnInit {
  route_parameter: any;

  constructor(private _route: ActivatedRoute) { }

  ngOnInit() {
  	this._route.params.subscribe(params => {
  		console.log('Got the detail_id! ', params);

	  	this.route_parameter = params;
  	});

  }

}
