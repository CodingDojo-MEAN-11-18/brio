const express = require('express');

const app = express();
const port = 8000;



app.use(express.static(__dirname + '/public/dist/public'));

app.listen(port, function() {
	console.log(`Server is listening on 127.0.0.1:${port}`);
});