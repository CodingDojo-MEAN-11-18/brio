// Fix the errors in the Playground so that all the red bars are gone and the code still runs as desired.
// Make comments in the code to explain what each error was and how you fixed it.
// For assignment submission, upload a ".ts" file with the contents of the TypeScript Playground


// 1. Setting types.

// Typescript specifies the data type the variable can accept. 
// So, for 9 to be assigned to the variable, declare on the first line that myString can be a number.

// previously: var myString: string;
var myString: string | number;
// I can assign myString like this:
myString = "Bee stinger";
// Why is there a problem with this? What can I do to fix this?
myString = 9;



// 2. Setting the types for function parameters

// original code: function sayHello(name:string) {return Hello, ${name}!};

// first: for the function to run we need to encapsulate Hello, ${name}!
// with grave accent (`) as simple quotations won't work 
// -- it will only render it as a string.

// second: for the sayHello(9) to work, we need to add number as a possible value for the variable
// -- we need to specify the data type

function sayHello(name: string | number){
   return `Hello, ${name}!`;
}
// This is working great:
console.log(sayHello("Kermit"));
// Why isn't this working? I want it to return "Hello, 9!"
console.log(sayHello(9));




// 3. Optional parameters

// original code: 
// function fullName(firstName: string, lastName: string, middleName: string){
//    let fullName = ${firstName} ${middleName} ${lastName};
//    return fullName;
// }
// // This works:
// console.log(fullName("Mary", "Moore", "Tyler"));
// // What do I do if someone doesn't have a middle name?
// console.log(fullName("Jimbo", "Jones"));

// first: for the fullName to accept a string data_type, we need to specify it before giving it a value.

// second: to make the ${firstName} etc. to be displayed dynamically, we need to surround the string with grave accent (`)

// third: to make fullName("Jimbo", "Jones"); work, we need to make middleName an optional parameter as the title says by adding a question mark after the variable name.

// the if else condition is to make sure that the function will not produce an 'undefined' string in the middle of the sentence if the middleName is not provided.

// If we let fullName as is without specifying the data_type, it will return a function instead.
function fullName(firstName: string, lastName: string, middleName?: string) {

	let fullName: string;

	if (middleName) {
	   	fullName = `${firstName} ${middleName} ${lastName}`;
	} else {
		fullName = `${firstName} ${lastName}`;
	}
   	return fullName;
}
// This works:
console.log(fullName("Mary", "Moore", "Tyler"));
// What do I do if someone doesn't have a middle name?
console.log(fullName("Jimbo", "Jones"));



// 4. Interfaces and function parameters

// original code: 

// const jay = {
//    firstName: "Jay",
//    lastName: "Patel",
//    belt: 4
// }

// first: the grave accent (`);

// second: belt should be replaced with belts


interface Student {
   firstName: string;
   lastName: string;
   belts: number;
}
function graduate(ninja: Student){
   return `Congratulations, ${ninja.firstName} ${ninja.lastName}, you earned ${ninja.belts} belts!`;
}
const christine = {
   firstName: "Christine",
   lastName: "Yang",
   belts: 2
}
const jay = {
   firstName: "Jay",
   lastName: "Patel",
   belts: 4,
   others: 20,
}

// This seems to work fine:
console.log(graduate(christine));
// This one has problems:
console.log(graduate(jay));



// 5. Classes and function parameters


// original code:

// const shane = Ninja();
// const turing = {
// 	fullName: "Alan Turing",
// 	firstName: "Alan",
// 	lastName: "Turing",
// }

// in order for us to make an instance of a class,
// we need to indicate the 'new' before class name.
// and we also have to provide values for the parameters on the constructor function.

// The second issue is that we need to completely imitate the class as it has a debug function.

class Ninja {
   fullName: string;
   constructor(
      public firstName: string,
      public lastName: string){
         this.fullName = `${firstName} ${lastName}`;
      }
   debug(){
      console.log("Console.log() is my friend.")
   }
}
// This is not making an instance of Ninja, for some reason:
const shane = new Ninja('Shane', 'Smith');
// Since I'm having trouble making an instance of Ninja, I decided to do this:
const turing = {
	fullName: "Alan Turing",
	firstName: "Alan",
	lastName: "Turing",
	debug: function() {
	   	console.log('This is also a console.log()');
	},
}
// Now I'll make a study function, which is a lot like our graduate function from above:
function study(programmer: Ninja){
   return `Ready to whiteboard an algorithm, ${programmer.fullName}?`
}
// Now this has problems:
console.log(study(turing));
//console.log(study(shane));



// 6. Arrow functions

// previously: var square = x => {x * x};
// if the arrow function is surrounded with braces, it should have a return statement.

// previously: var multiply = x, y => x * y;
// if the arrow function have multiple parameters, enclose it with parentheses.

// previously: var math = (x, y) => let sum = x+y; let product = x*y; etc.
// if the arrow function use too many lines of code, make sure to enclose it with braces and have a return statement.

var increment = x => x + 1;
// This works great:
console.log(increment(3));
var square = x => {return x * x};
// This is not showing me what I want:
console.log(square(4));
// This is not working:
var multiply = (x,y) => x * y;
// Nor is this working:
var math = (x, y) => {
	let sum = x + y;
	let product = x * y;
	let difference = Math.abs(x-y);
	return [sum, product, difference];
}

console.log(multiply(3, 4));
console.log(math(5, 6));



// 7. Arrow functions and 'this'

// 'this' will be pointing to 'window' that will execute the function.

// using arrow function works since 'this' is captured by it.

class Elephant {
   constructor(public age: number){}
   birthday = () => {
      this.age++;
   }
}
const babar = new Elephant(8);
setTimeout(babar.birthday, 1000)
setTimeout(function(){
   console.log(`Babar's age is ${babar.age}.`)
}, 2000)
// Why didn't babar's age change? Fix this by using an arrow function in the Elephant class.
