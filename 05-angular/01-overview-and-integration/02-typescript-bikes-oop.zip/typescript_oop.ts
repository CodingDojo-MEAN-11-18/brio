class Bike {

    miles: number
    price: number
    max_speed: string
    brand: string

    constructor(
        price: number,
        max_speed: string,
        brand: string ) {
        this.miles = 0;
        this.price = price;
        this.max_speed = max_speed;
        this.brand = brand;
    } 

    displayInfo = () => {

        console.log(`Brand: ${this.brand}`);
        console.log(`Price: $${this.price}`);
        console.log(`Max Speed: ${this.max_speed}`);
        console.log(`Miles: ${this.miles}`);

        return this
    }

    ride = () => {

        this.miles += 10;
        console.log(`${this.brand} Riding..`);
        console.log(`Reached ${this.miles} miles!`);

        return this
    }

    reverse = () => {
        // to make sure that the miles will not go negative

        if (this.miles - 5 > 0) {
            console.log(`${this.brand} Reversing..`);
            this.miles -= 5;

            console.log(`Reached ${this.miles} miles!`);

        } else {
            this.miles = 0;
            console.log(`${this.brand} have gone back to ${this.miles}!`);
            
        }

        return this
    }


}


let trek = new Bike(2500, '20mph', 'Trek');
let diamondback = new Bike(3000, '20mph', 'Diamondback');
let pivot = new Bike(3500, '20mph', 'Pivot');

// all the functions can be chained
trek.ride().ride().ride().reverse().displayInfo();
diamondback.ride().ride().reverse().reverse().displayInfo();
pivot.reverse().reverse().reverse().displayInfo();

