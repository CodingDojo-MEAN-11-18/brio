import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private _http: HttpClient) {
  	console.log('constructor initiated');	
  	this.getTasks();
  }

  getTasks() {
  	return this._http.get('/tasks/all')
  }

  getSpecificTask(task_id) {
  	let tempObservable = this._http.get(`/tasks/${task_id}`);

  	console.log('getting specific task..');
  	tempObservable.subscribe(data => console.log('Got a specific task!', data));
  }
}
