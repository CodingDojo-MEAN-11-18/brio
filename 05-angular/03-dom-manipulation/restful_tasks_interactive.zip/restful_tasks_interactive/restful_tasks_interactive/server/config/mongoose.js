const mongoose = require('mongoose');

const mongo_url = 'mongodb://127.0.0.1/restful_task_api';
mongoose.connect(mongo_url, {useNewUrlParser: true});
mongoose.Promise = global.Promise;

const db = mongoose.connection;



db.once('open', function(callback) {
	console.log('connection to db is now open!');
});

db.on('error', function() {
	console.error('MongoDB connection error!');
});



module.exports = db;