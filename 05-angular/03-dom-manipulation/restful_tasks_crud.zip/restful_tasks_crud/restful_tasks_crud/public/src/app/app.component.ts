import { Component, OnInit } from '@angular/core';

import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'public';
  tasks = [];
  task_showed = [];
  new_task:any;
  update_task:any;


  constructor(private _httpService: HttpService) {}

  ngOnInit() {
    this.getTasksFromService();
    this.new_task = {title: '', description: ''};
    this.update_task = {title: '', description: ''};
  }

  getTasksFromService() {
  	let tempObservable = this._httpService.getTasks();

  	tempObservable.subscribe(data => {
  		console.log('Got all the tasks!', data);

  		this.tasks = data['tasks'];
  	});
  }

  showThisTask(task:object) {
    console.log(task);
    this.task_showed = [task];
    console.log(this.task_showed);
  }

  createTask(event) {
    // event.preventDefault();
    let result = this._httpService.addTask(this.new_task);

    result.subscribe(data => {
      console.log(data);

      if (data['status'] == true) {
        this.tasks.push(data['task']);
      }

    });

    this.new_task = {title: '', description: ''};
  }

  deleteTask(task:object) {
    console.log('delete this task: ', task);
    this._httpService.destroyTask(task['_id']).subscribe(data => {
      console.log(data);

      if (data['status'] == true) {
        let index = this.tasks.indexOf(task);

        this.tasks.splice(index, 1);
      }
    });
  }

  editTask(task:object) {
    console.log('edit this task: ', task);
    this._httpService.updateTask(task['_id'], task).subscribe(data => {
      console.log(data);

      if (data['status'] == true) {
        let index = this.tasks.indexOf(task);

        this.tasks[index] = data['task'];
        this.update_task = {title: '', description: ''};
      }

    });
  }

  showEditForm(task) {
    this.update_task = task;
  }

  cancelEdit() {
    this.update_task = {title: '', description: ''};
  }

}
