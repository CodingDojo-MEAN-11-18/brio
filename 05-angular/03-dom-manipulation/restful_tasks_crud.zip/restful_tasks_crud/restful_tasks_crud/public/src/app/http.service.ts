import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private _http: HttpClient) { }

  getTasks() {
  	return this._http.get('/tasks/all')
  }

  addTask(new_task) {
  	return this._http.post('/tasks/create', new_task)
  }

  destroyTask(task_id) {
  	return this._http.delete(`/tasks/${task_id}/destroy`);
  }

  updateTask(task_id, task) {
  	return this._http.put(`/tasks/${task_id}/edit`, task);
  }
}
