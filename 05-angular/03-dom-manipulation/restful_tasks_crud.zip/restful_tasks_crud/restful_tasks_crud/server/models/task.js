const mongoose = require('mongoose');

const Schema = mongoose.Schema;



let TaskSchema = new Schema({
	title: {
		type: String,
		required: true,
	},
	description: {
		type: String,
		default: '',
	},
	completed: {
		type: Boolean,
		default: false,
	},
	created_at: {
		type: Date,
		default: Date.now(),
	},
	update_at: {
		type: Date,
		default: Date.now(),
	},
});

let Task = mongoose.model('Task', TaskSchema);


module.exports = Task;