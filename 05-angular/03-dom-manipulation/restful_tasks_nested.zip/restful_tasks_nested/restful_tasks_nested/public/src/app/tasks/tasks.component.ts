import { Component, OnInit } from '@angular/core';

import { HttpService } from '../http.service';

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.css']
})
export class TasksComponent implements OnInit {
  tasks = [];
  task_showed = [];

  constructor(private _httpService: HttpService) { }

  ngOnInit() {
  }

  getTasksFromService() {
  	let tempObservable = this._httpService.getTasks();

  	tempObservable.subscribe(data => {
  		console.log('Got all the tasks!', data);

  		this.tasks = data['tasks'];
  	});
  }

  showThisTask(task:object) {
    console.log(task);
    this.task_showed = [task];
    console.log(this.task_showed);
  }

}
