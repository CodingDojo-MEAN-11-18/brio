const mongoose = require('mongoose');

const Task = require(__dirname + '/../models/task.js');
const ObjectId = mongoose.Types.ObjectId;


let task_functions = {

	all: function(req, res) {
		// get all tasks in database;
		// res.send('hello world');

		Task.find({}).exec(function(error, tasks) {
			status = false;
			if (!error) {
				status = true;
			}

			res.json( {status: status, tasks: tasks} );
			// res.send(tasks);
		});

	},

	show: function(req, res) {
		// get specific task by id;
		// res.send('hello show');

		Task.find({_id: ObjectId(req.params.id)}).exec(function(error, task) {
			let status = true;
			let messages = {};

			if (error) {
				status = false;
			}

			res.json({
				status: status, 
				messages: messages, 
				task: task
			});
		});

	},

	create: function(req, res) {
		// create new task;
		// res.send('hello create');

		console.log(req.body);
		let new_task = new Task(req.body);

		new_task.save(function(error) {
			let status = true;
			let messages = {};

			if (error) {
				status = false;

				Object.keys(error.errors).forEach(function(err, index) {
					messages[err] = error.errors[err].message;
				});
			}


			res.json({status: status, messages:messages});
		});
		
	},

	edit: function(req, res) {
		// edit specific task by id;
		// res.send('hello edit');

		Task.findOneAndUpdate(
			{_id: ObjectId(req.params.id)},
			{$set: req.body},
			{runValidators: true, new: true},
			function(error, task) {
				let status = true;
				let messages = {};

				if (error) {
					status = false;

					Object.keys(error.errors).forEach(function(err, index) {
						messages[err] = error.errors[err].message;
					});
				}

				res.json({status: status, messages:messages});
			}
		);

	},

	destroy: function(req, res) {
		// delete specific task by id;
		res.send('hello destroy');
		
		Task.findOneAndDelete(
			{_id: ObjectId(req.params.id)},
			function(error, task) {
				let status = true;
				let messages = {};

				if (error) {
					status = false;

					Object.keys(error.errors).forEach(function(err, index) {
						messages[err] = error.errors[err].message;
					});
				}

				res.json({status: status, messages:messages});
			}
		);

	},

}


module.exports = task_functions;