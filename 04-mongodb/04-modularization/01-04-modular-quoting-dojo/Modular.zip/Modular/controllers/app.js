const body_parser = require('body-parser');
const cookie_parser = require('cookie-parser');
const express = require('express');
const flash = require('connect-flash');
const mongoose = require('mongoose');
const session = require('express-session');

const app = express();
const port = 8000;
const sessionStore = new session.MemoryStore;

const quote_route = require('./server/config/routes.js');

const db = mongoose.connection;
// console.log(db);

db.once('open', function(callback) {console.log('connection to db open!')});
db.on('error', console.error.bind(console, 'MongoDB connection error'));

app.use(body_parser.json());
app.use(body_parser.urlencoded({extended: true}));
app.use(cookie_parser());
app.use(express.static('static'));
app.use(session({
	cookie: {maxAge: 86000},
	store: sessionStore,
	saveUninitialized: true,
	resave: 'true',
	secret: 'number one secret',
}));
app.use(flash());
app.use(quote_route);


app.set('view engine', 'ejs');

app.listen(port, function() {
	console.log(`App is listening on 127.0.0.1:${port}!`);
});