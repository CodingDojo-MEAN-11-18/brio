const body_parser = require('body-parser');
const cookie_parser = require('cookie-parser');
const express = require('express');
const flash = require('connect-flash');
const session = require('express-session');

const app = express();
const port = 8000;
const sessionStore = new session.MemoryStore;

const db = require('./server/config/mongoose.js');
const quote_route = require('./server/config/routes.js');

// ejs!
app.set('view engine', 'ejs');

// settings!
app.use(body_parser.json());
app.use(body_parser.urlencoded({extended: true}));
app.use(cookie_parser());
app.use(express.static('static'));
app.use(session({
	cookie: {maxAge: 86000},
	store: sessionStore,
	saveUninitialized: true,
	resave: 'true',
	secret: 'number one secret',
}));
app.use(flash());

// routes!
app.use(quote_route);

// server!
app.listen(port, function() {
	console.log(`App is listening on 127.0.0.1:${port}!`);
});