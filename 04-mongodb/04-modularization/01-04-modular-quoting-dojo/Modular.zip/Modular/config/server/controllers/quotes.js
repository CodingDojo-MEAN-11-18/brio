const date_format = require('dateformat');
const url = require('url');


const Quote = require('../models/quote.js');


var quote_functions = {

 	index: function(request, response) {
		response.render('index', {messages: request.flash('error_messages')});
	},

	show: function(request, response) {

		Quote.find({}).sort({created_at: -1}).exec(function(error, quotes) {

			let to_render = {
				quotes: quotes, 
				date_format: date_format,
			}

			response.render('quotes', to_render);

		});

	},

	create: function(request, response, next) {

		console.log('create quote');

		// response.send('Create Quotes');
		// response.send(request.body);
		let new_quote = new Quote({
			name: request.body['name'],
			quote: request.body['quote'],
			created_at: Date.now(),
		});

		new_quote.save(function(error) {

			if (error) {
				Object.keys(error.errors).forEach(function(key, index) {
					request.flash('error_messages', error.errors[key].message);
				});

				response.redirect(url.format({
					pathname: '/',
				}));

			} else {
				response.redirect(url.format({
					pathname: '/quotes',
				}));

			}

		});

	},

};



 module.exports = quote_functions;