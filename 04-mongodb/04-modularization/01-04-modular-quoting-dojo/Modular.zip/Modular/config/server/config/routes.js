const express = require('express');
const router = new express.Router();

const quotes = require('../controllers/quotes.js');


router.get('/', quotes.index);
router.get('/quotes', quotes.show);
router.post('/quotes', quotes.create);


module.exports = router;