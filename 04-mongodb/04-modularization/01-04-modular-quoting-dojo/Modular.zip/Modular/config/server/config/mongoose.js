const mongoose = require('mongoose');

const mongoDB = 'mongodb://127.0.0.1/quotes_dojo_routes_controllers_models_mongoose';

mongoose.connect(mongoDB, {useNewUrlParser: true});
mongoose.Promise = global.Promise;

const db = mongoose.connection;
// console.log(db);


db.once('open', function(callback) {console.log('connection to db open!')});
db.on('error', console.error.bind(console, 'MongoDB connection error'));


module.exports = db;