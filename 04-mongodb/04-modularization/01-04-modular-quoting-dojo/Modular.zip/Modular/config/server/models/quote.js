const mongoose = require('mongoose');

const Schema = mongoose.Schema;


const quoteSchema = new Schema({
	name: {
		type: String,
		minlength: [4, 'Name should be more than 4 characters'],
		maxlength: 32,
		required: [true, 'Name is required'],
	},
	quote: {
		type: String,
		minlength: [15, 'Quote should be more than 15 characters'],
		required: [true, 'Quote is required'],
	},
	created_at: Date,
});

const Quote = mongoose.model('Quote', quoteSchema);


module.exports = Quote;