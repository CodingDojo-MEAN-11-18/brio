const express = require('express');
const router = new express.Router();
const mongoose = require('mongoose');
const date_format = require('dateformat');
const url = require('url');

const Schema = mongoose.Schema;

const quoteSchema = new Schema({
	name: {
		type: String,
		minlength: [4, 'Name should be more than 4 characters'],
		maxlength: 32,
		required: [true, 'Name is required'],
	},
	quote: {
		type: String,
		minlength: [15, 'Quote should be more than 15 characters'],
		required: [true, 'Quote is required'],
	},
	created_at: Date,
});

const Quote = mongoose.model('Quote', quoteSchema);




router.get('/', function(request, response) {
	response.render('index', {messages: request.flash('error_messages')});
});


router.get('/quotes', function(request, response) {

	Quote.find({}).sort({created_at: -1}).exec(function(error, quotes) {

		let to_render = {
			quotes: quotes, 
			date_format: date_format,
		}

		response.render('quotes', to_render);

	});

});


router.post('/quotes', function(request, response, next) {
	console.log('create quote');

	// response.send('Create Quotes');
	// response.send(request.body);
	let new_quote = new Quote({
		name: request.body['name'],
		quote: request.body['quote'],
		created_at: Date.now(),
	});

	new_quote.save(function(error) {

		if (error) {
			Object.keys(error.errors).forEach(function(key, index) {
				request.flash('error_messages', error.errors[key].message);
			});

			response.redirect(url.format({
				pathname: '/',
			}));

		} else {
			response.redirect(url.format({
				pathname: '/quotes',
			}));

		}

	});

});


module.exports = router;