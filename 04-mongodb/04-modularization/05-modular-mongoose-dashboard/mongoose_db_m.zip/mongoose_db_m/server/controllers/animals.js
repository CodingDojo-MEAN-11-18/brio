const mongoose = require('mongoose');
const url = require('url');

const ObjectId = mongoose.Types.ObjectId;

const Animal = require('../models/animal.js');



var animal_controllers = {
	dashboard: function(request, response) {
		// displays all the animals
		// response.send('display all the animals');

		Animal.find({}).exec(function(error, animals) {

			let to_render = {
				animals: animals,
				messages: request.flash('errors'),
			};

			response.render('dashboard', to_render);
		});
	},

	add_form: function(request, response) {
		// form of adding a mongoose animal.

		response.render('add_form', {messages: request.flash('errors'),});
		// response.send('form of adding an animal');

	},

	create:  function(request, response) {
		// action handler of /animals/new
		// response.send('action handler of /animals/new');

		console.log(request.body);

		var new_animal = new Animal({
			name: request.body.name,
		});

		new_animal.save(function(error) {
			if (error) {

				Object.keys(error.errors).forEach(function(key, index) {
					request.flash('errors', error.errors[key].message);
				});

				response.redirect(url.format({
					pathname: '/animals/new',
				}));

				response
			} else {
				response.redirect(url.format({
					pathname: '/',
				}));
			}
		});
	},

	edit_form: function(request, response) {
		// form for editing mongoose animal.
		// response.send('form for editing mongoose animal.');

		Animal.findOne({_id: ObjectId(request.params.id)}).exec(function(error, animal) {
			console.log(animal);

			let to_render = {
				animal: animal,
				messages: request.flash('errors'),
			};

			response.render('edit_form', to_render);
		});
	},

	destroy: function(request, response) {
		// delete a mongoose.
		// response.send('delete a mongoose.');

		Animal.findOneAndDelete(
			{_id: ObjectId(request.params.id)}, 
			function(error, animal) {
				if (error) {

					Object.keys(error.errors).forEach(function(key, index) {
						request.flash('errors', error.errors[key].message);
					});

					response.redirect(url.format({
						pathname: '/animals/' + request.params.id,
					}));
				} else {
					response.redirect(url.format({
						pathname: '/',
					}));
				}
			}
		);
	},

	show: function(request, response) {
		// displays the information about the mongoose animal.
		// response.send('displays the information about the mongoose animal.');

		Animal.findOne({_id:ObjectId(request.params.id)}).exec(function(error, animal) {
			// console.log(animal);
			let to_render = {
				animal: animal,
				messages: request.flash('errors'),
			};

			response.render('detail', to_render);
		});
	},

	update: function(request, response) {
		// action handler of /animals/edit/:id
		// response.send('action handler of /animals/edit/:id');

		Animal.findOneAndUpdate(
			{_id: ObjectId(request.params.id)}, 
			{$set: request.body}, 
			{runValidators: true, new: true}, 
			function(error, animal) {

				// console.log(request.body);

				if (error) {

					Object.keys(error.errors).forEach(function(key, index) {
						request.flash('errors', error.errors[key].message);
					});
					
					response.redirect(url.format({
						pathname: '/animals/edit/' + request.params.id.toString(),
					}));

				} else {

					// console.log(animal.name);

					response.redirect(url.format({
						pathname: '/animals/' + animal.id,
					}));

				}
			}
		);
	},
};

module.exports = animal_controllers;