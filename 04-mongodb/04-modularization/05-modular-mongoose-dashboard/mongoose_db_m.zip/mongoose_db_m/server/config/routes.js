const express = require('express');
const router = express.Router();

const animal_controller = require('../controllers/animals.js');

router.get('/', animal_controller.dashboard);
router.get('/animals/new', animal_controller.add_form);
router.get('/animals/edit/:id', animal_controller.edit_form);
router.post('/animals', animal_controller.create);
router.post('/animals/destroy/:id', animal_controller.destroy);
router.get('/animals/:id', animal_controller.show);
router.post('/animals/:id', animal_controller.update);


module.exports = router;