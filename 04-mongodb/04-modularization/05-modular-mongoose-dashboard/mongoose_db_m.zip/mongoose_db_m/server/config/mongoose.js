const mongoose = require('mongoose');

const mongoDB = 'mongodb://127.0.0.1/mongoose_dash_modularized';
mongoose.connect(mongoDB, {useNewUrlParser: true});
mongoose.Promise = global.Promise;

const db = mongoose.connection;




db.once('open', function(callback) {console.log('connection to db now open!')});
db.on('error', console.error.bind(console, 'MongoDB connection error!'));


module.exports = db;