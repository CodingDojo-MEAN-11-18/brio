const body_parser = require('body-parser');
const cookie_parser = require('cookie-parser');
const express = require('express');
const flash = require('connect-flash');
const session = require('express-session');

const app = express();
const port = 8000;
const session_store = new session.MemoryStore;

const db = require('./server/config/mongoose.js');
const animal_route = require('./server/config/routes.js');

app.use(body_parser.json());
app.use(body_parser.urlencoded({extended: true}));
app.use(cookie_parser());
app.use(express.static('./client/static'));
app.use(session({
	cookie: {maxAge: 86000},
	store: session_store,
	saveUninitialized: true,
	resave: 'true',
	secret: 'number one secret',
}));
app.use(flash());
app.use(animal_route);

app.set('view engine', 'ejs');
app.set('views', './client/views');

app.listen(port, function() {
	console.log(`Mongoose Dashboard is listening on 127.0.0.1:${port}!`);
});

