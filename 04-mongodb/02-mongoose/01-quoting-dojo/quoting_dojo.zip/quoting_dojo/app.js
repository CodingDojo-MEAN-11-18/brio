const body_parser = require('body-parser');
const cookie_parser = require('cookie-parser');
const date_format = require('dateformat');
const express = require('express');
const flash = require('connect-flash');
const mongoose = require('mongoose');
const session = require('express-session');
const url = require('url');

const app = express();
const port = 8000;

const mongoDB = 'mongodb://127.0.0.1/quotes_dojo';
mongoose.connect(mongoDB, {useNewUrlParser: true});
mongoose.Promise = global.Promise;

const Schema = mongoose.Schema;
const db = mongoose.connection;
// console.log(db);

db.once('open', function(callback) {console.log('connection to db open!')});
db.on('error', console.error.bind(console, 'MongoDB connection error'));

const quoteSchema = new Schema({
	name: {
		type: String,
		minlength: [4, 'Name should be more than 4 characters'],
		maxlength: 32,
		required: [true, 'Name is required'],
	},
	quote: {
		type: String,
		minlength: [15, 'Quote should be more than 15 characters'],
		required: [true, 'Quote is required'],
	},
	created_at: Date,
});

const Quote = mongoose.model('Quote', quoteSchema);

const session_store = new session.MemoryStore;

app.use(body_parser.json());
app.use(body_parser.urlencoded({extended: true}));
app.use(cookie_parser());
app.use(express.static('static'));
app.use(session({
	cookie: {maxAge: 86000},
	store: session_store,
	saveUninitialized: true,
	resave: 'true',
	secret: 'number one secret',
}));
app.use(flash());


app.set('view engine', 'ejs');

app.listen(port, function() {
	console.log(`App is listening on 127.0.0.1:${port}!`);
});


app.get('/', function(request, response) {
	response.render('index', {messages: request.flash('error_messages')});
});


app.get('/quotes', function(request, response) {

	Quote.find({}).sort({created_at: -1}).exec(function(error, quotes) {

		let to_render = {
			quotes: quotes, 
			date_format: date_format,
		}

		response.render('quotes', to_render);

	});

});


app.post('/quotes', function(request, response, next) {
	console.log('create quote');

	// response.send('Create Quotes');
	// response.send(request.body);
	let new_quote = new Quote({
		name: request.body['name'],
		quote: request.body['quote'],
		created_at: Date.now(),
	});

	new_quote.save(function(error) {

		if (error) {
			Object.keys(error.errors).forEach(function(key, index) {
				request.flash('error_messages', error.errors[key].message);
			});

			response.redirect(url.format({
				pathname: '/',
			}));

		} else {
			response.redirect(url.format({
				pathname: '/quotes',
			}));

		}

	});

});




// app.use(function(error, request, response, next) {
// 	Object.keys(error.errors).forEach(function(key, index) {
// 		let err = {'field': key, 'message': error.errors[key].message};
// 		request.flash('error_messages', err['message']);
// 	});
// 	// console.log(request.flash('error_messages'));
// 	// console.log(error);
// 	console.log('hello there!');
// });