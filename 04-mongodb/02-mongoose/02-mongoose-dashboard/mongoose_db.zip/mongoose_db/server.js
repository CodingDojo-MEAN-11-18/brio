const body_parser = require('body-parser');
const cookie_parser = require('cookie-parser');
const express = require('express');
const flash = require('connect-flash');
const mongoose = require('mongoose');
const session = require('express-session');
const url = require('url');

const app = express();
const port = 8000;
const session_store = new session.MemoryStore;
const ObjectId = mongoose.Types.ObjectId;

const mongoDB = 'mongodb://127.0.0.1/mongoose_dash';
mongoose.connect(mongoDB, {useNewUrlParser: true});
mongoose.Promise = global.Promise;
const db = mongoose.connection;
const Schema = mongoose.Schema;

db.once('open', function(callback) {console.log('connection to db now open!')});
db.on('error', console.error.bind(console, 'MongoDB connection error!'));


const AnimalSchema = new Schema({
	name: {
		type: String,
		required: [true, 'Animal name is required'],
	},
});

const Animal = mongoose.model('Animal', AnimalSchema);


app.use(body_parser.json());
app.use(body_parser.urlencoded({extended: true}));
app.use(cookie_parser());
app.use(express.static('static'));
app.use(flash());
app.use(session({
	cookie: {maxAge: 86000},
	store: session_store,
	saveUninitialized: true,
	resave: 'true',
	secret: 'number one secret',
}));

app.set('view engine', 'ejs');

app.listen(port, function() {
	console.log(`Mongoose Dashboard is listening on 127.0.0.1:${port}!`);
});



app.get('/', function(request, response) {
	// displays all the animals
	// response.send('display all the animals');

	Animal.find({}).exec(function(error, animals) {

		let to_render = {
			animals: animals,
			messages: request.flash('errors'),
		};

		response.render('dashboard', to_render);
	});
});

app.get('/animals/new', function(request, response) {
	// form of adding a mongoose animal.

	response.render('add_form', {messages: request.flash('errors'),});
	// response.send('form of adding an animal');

});

app.post('/animals', function(request, response) {
	// action handler of /animals/new
	// response.send('action handler of /animals/new');

	console.log(request.body);

	var new_animal = new Animal({
		name: request.body.name,
	});

	new_animal.save(function(error) {
		if (error) {

			Object.keys(error.errors).forEach(function(key, index) {
				request.flash('errors', error.errors[key].message);
			});

			response.redirect(url.format({
				pathname: '/animals/new',
			}));

			response
		} else {
			response.redirect(url.format({
				pathname: '/',
			}));
		}
	});
});

app.get('/animals/edit/:id', function(request, response) {
	// form for editing mongoose animal.
	// response.send('form for editing mongoose animal.');

	Animal.findOne({_id: ObjectId(request.params.id)}).exec(function(error, animal) {
		console.log(animal);

		let to_render = {
			animal: animal,
			messages: request.flash('errors'),
		};

		response.render('edit_form', to_render);
	});
});

app.post('/animals/destroy/:id', function(request, response) {
	// delete a mongoose.
	// response.send('delete a mongoose.');

	Animal.findOneAndDelete(
		{_id: ObjectId(request.params.id)}, 
		function(error, animal) {
			if (error) {

				Object.keys(error.errors).forEach(function(key, index) {
					request.flash('errors', error.errors[key].message);
				});

				response.redirect(url.format({
					pathname: '/animals/' + request.params.id,
				}));
			} else {
				response.redirect(url.format({
					pathname: '/',
				}));
			}
		}
	);
});

app.get('/animals/:id', function(request, response) {
	// displays the information about the mongoose animal.
	// response.send('displays the information about the mongoose animal.');

	Animal.findOne({_id:ObjectId(request.params.id)}).exec(function(error, animal) {
		// console.log(animal);
		let to_render = {
			animal: animal,
			messages: request.flash('errors'),
		};

		response.render('detail', to_render);
	});
});

app.post('/animals/:id', function(request, response) {
	// action handler of /animals/edit/:id
	// response.send('action handler of /animals/edit/:id');



	Animal.findOneAndUpdate(
		{_id: ObjectId(request.params.id)}, 
		{$set: request.body}, 
		{runValidators: true, new: true}, 
		function(error, animal) {

			// console.log(request.body);

			if (error) {

				Object.keys(error.errors).forEach(function(key, index) {
					request.flash('errors', error.errors[key].message);
				});
				
				response.redirect(url.format({
					pathname: '/animals/edit/' + request.params.id.toString(),
				}));

			} else {

				// console.log(animal.name);

				response.redirect(url.format({
					pathname: '/animals/' + animal.id.toString(),
				}));

			}
		}
	);
});


